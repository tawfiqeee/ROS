SpartonCompassIMU
=================

Sparton Digital Compass ROS Driver for AHRS-8 / GEDC-6 / DC-4 , NorthTek output
Copyright (c) 2013, Cheng-Lung Lee, University of Detroit Mercy
